export class User {
     name: string;
     password: string;
    //  address: string;
     constructor(un:string,password:string){
        this.name=un;
        this.password=password;
        
    }
}